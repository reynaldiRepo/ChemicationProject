var alertDiv = document.getElementById('alertMsg');
if (alertDiv.innerHTML=='') {
    alertDiv.style.display = 'none';
}else{
    alertDiv.style.display = '';
}

var alertDiv = document.getElementById('alertError');
if (alertDiv.innerHTML=='') {
    alertDiv.style.display = 'none';
}else{
    alertDiv.style.display = '';
}