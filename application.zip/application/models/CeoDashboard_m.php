<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class CeoDashboard_m extends CI_Model{
    public function login(){
        $tim = array(
            'email'=>$this->input->post('email_ceo'),
            'PASSWORD'=>$this->input->post('password_ceo')
        );
        $SQL = 'select *
                from tim_ceo 
                where email ="'.$tim['email'].'" and '.'PASSWORD ="'.$tim['PASSWORD'].'"';
        $query = $this->db->query($SQL);

        if ($query->num_rows() == 1) {
            return true;
        }else{
            return false;
        }
    }

    public function getData(){
        $tim = array(
            'email'=>$this->input->post('email_ceo'),
            'PASSWORD'=>$this->input->post('password_ceo')
        );
        $SQL = 'select *
                from tim_ceo 
                where email ="'.$tim['email'].'" and '.'PASSWORD ="'.$tim['PASSWORD'].'"';
        $query = $this->db->query($SQL);
        if ($query->num_rows() > 0) {
            return $query->result();
        }else{
            return false;
        }

    }

    public function home_model($id){
        $SQL = "select (case
                when kc.Tim_id = '".$id."' and ac1.Tim_id = '".$id."' and ac2.Tim_id = '".$id."' 
                and dt.Status_pembayaran = '03' THEN 'true'
                else 'false'
                end) as 'cek_data'
                from ketua_ceo kc, anggota1_ceo ac1, anggota2_ceo ac2, detailpendaftaran_ceo dt
                where dt.Tim_id = '".$id."' and kc.Tim_id = '".$id."' and ac1.Tim_id = '".$id."' and ac2.Tim_id = '".$id."' ";
        $query1 = $this->db->query($SQL);
        $query1 = $query1->result(); 


        $SQL2 = "select * 
                from dashboard_ceo_news
                order by id DESC";
        $query2 = $this->db->query($SQL2);
        $query2 = $query2->result(); 

        $SQL3 = "select * 
        from jadwal_ceo";
        $query3 = $this->db->query($SQL3);
        $query3 = $query3->result(); 

        $cek = false;
        foreach($query1 as $post){
			$cek = $post->cek_data;
            }
            
        if ($cek == 'true') {
            $HomeData['cek'] = true;
            $HomeData['news'] = $query2;
            $HomeData['jadwal'] = $query3;
            return $HomeData;
        }
        else{
            $HomeData['cek'] = false;
            $HomeData['news'] = $query2;
            $HomeData['jadwal'] = $query3;
            return $HomeData;
        }
    }

    public function cek_data_anggota($id){
        $SQL_all = "select (case
                    when kc.Tim_id = '".$id."' and ac1.Tim_id = '".$id."' and ac2.Tim_id = '".$id."' 
                    THEN 'true'
                    else 'false'
                    end) as 'cek_data'
                    from ketua_ceo kc, anggota1_ceo ac1, anggota2_ceo ac2
                    where kc.Tim_id = '".$id."' and ac1.Tim_id = '".$id."' and ac2.Tim_id = '".$id."' ";
        $cek_data = $this->db->query($SQL_all);
        $cek_data = $cek_data->result();
        foreach($cek_data as $post){
			$cek_data = $post->cek_data;
            };
            
        if ($cek_data == 'true') {
            return true;
        }else{return false;}
        
    }

    public function get_ketua($id){
        $SQL = "select *
                from ketua_ceo
                where Tim_id = '".$id."' ";
        $data = $this->db->query($SQL);
        if ($data->num_rows() > 0 ) {
            return $data->result();
        }
        else{
            return false;
        }
    }

    public function get_anggota1($id){
        $SQL = "select *
                from anggota1_ceo
                where Tim_id = '".$id."' ";
        $data = $this->db->query($SQL);
        if ($data->num_rows() > 0 ) {
            return $data->result();
        }
        else{
            return false;
        }
    }

    public function get_anggota2($id){
        $SQL = "select *
                from anggota2_ceo
                where Tim_id = '".$id."' ";
        $data = $this->db->query($SQL);
        if ($data->num_rows() > 0 ) {
            return $data->result();
        }
        else{
            return false;
        }
    }

    public function updata_insert_ketua($id, $scan, $foto){        
        $data = array(
            'NISN'=>$this->input->post('nisn_ketua_ceo'),
            'Tim_id'=>$id,
            'Nama_ketua'=>$this->input->post('nama_ketua_ceo'),
            'Tempat_Lahir'=>$this->input->post('kota_ketua_ceo'),
            'tanggal_lahir'=>$this->input->post('tgl_ketua_ceo'),
            'Jenis_kelamin'=>$this->input->post('jk_ketua_ceo'),
            'Kelas'=>$this->input->post('kelas_ketua_ceo'),
            'KontakWaLine'=>$this->input->post('kontak_ketua_ceo'),
            'Alamat'=>$this->input->post('alamat_ketua_ceo'),
            'Pasfoto'=> $foto,
            'KartuPelajar'=> $scan
            
        );

        $get_ketua = $this->get_ketua($id);
        if ($get_ketua != false) {
            $this->db->where('Tim_id',$id);
            $this->db->update('ketua_ceo', $data);

        }else{
            $this->db->where('Tim_id',$id);
            $this->db->insert('ketua_ceo', $data);
        }
        
        if ($this->db->affected_rows() > 0){
            return true;
        }
        else{
            return false;
        }
    }
    
    public function updata_insert_anggota1($id, $scan, $foto){        
        $data = array(
            'NISN'=>$this->input->post('nisn_anggota1_ceo'),
            'Tim_id'=>$id,
            'Nama_anggota1'=>$this->input->post('nama_anggota1_ceo'),
            'Tempat_Lahir'=>$this->input->post('kota_anggota1_ceo'),
            'tanggal_lahir'=>$this->input->post('tgl_anggota1_ceo'),
            'Jenis_kelamin'=>$this->input->post('jk_anggota1_ceo'),
            'Kelas'=>$this->input->post('kelas_anggota1_ceo'),
            'KontakWaLine'=>$this->input->post('kontak_anggota1_ceo'),
            'Alamat'=>$this->input->post('alamat_anggota1_ceo'),
            'Pasfoto'=> $foto,
            'KartuPelajar'=> $scan
            
        );

        $get_anggota1 = $this->get_anggota1($id);
        if ($get_anggota1 != false) {
            $this->db->where('Tim_id',$id);
            $this->db->update('anggota1_ceo', $data);

        }else{
            $this->db->where('Tim_id',$id);
            $this->db->insert('anggota1_ceo', $data);
        }
        
        if ($this->db->affected_rows() > 0){
            return true;
        }
        else{
            return false;
        }
    }

    public function updata_insert_anggota2($id, $scan, $foto){        
        $data = array(
            'NISN'=>$this->input->post('nisn_anggota2_ceo'),
            'Tim_id'=>$id,
            'Nama_anggota2'=>$this->input->post('nama_anggota2_ceo'),
            'Tempat_Lahir'=>$this->input->post('kota_anggota2_ceo'),
            'tanggal_lahir'=>$this->input->post('tgl_anggota2_ceo'),
            'Jenis_kelamin'=>$this->input->post('jk_anggota2_ceo'),
            'Kelas'=>$this->input->post('kelas_anggota2_ceo'),
            'KontakWaLine'=>$this->input->post('kontak_anggota2_ceo'),
            'Alamat'=>$this->input->post('alamat_anggota2_ceo'),
            'Pasfoto'=> $foto,
            'KartuPelajar'=> $scan
            
        );

        $get_anggota2 = $this->get_anggota2($id);
        if ($get_anggota2 != false) {
            $this->db->where('Tim_id',$id);
            $this->db->update('anggota2_ceo', $data);

        }else{
            $this->db->where('Tim_id',$id);
            $this->db->insert('anggota2_ceo', $data);
        }
        
        if ($this->db->affected_rows() > 0){
            return true;
        }
        else{
            return false;
        }
    }

    // pembayaran
    public function cek_pembayaran($id){
        $SQL = "select *
                from detailpendaftaran_ceo
                where Tim_id = '".$id."' ";
        $data = $this->db->query($SQL);
        if ($data->num_rows() > 0 ) {
            return array(
                'data'=>$data->result(),
                'cek' =>true
            );
        }
    }

    public function upload_pembayaran($id, $file){
        $data = array(
            'bukti_pembayaran' => $file,
            'Status_pembayaran' => '02'
        );
        $this->db->where('Tim_id', $id);
        $this->db->update('detailpendaftaran_ceo', $data);

        if ($this->db->affected_rows()>0){
            return true;
        }
        else{
            return false;
        }
    }

    public function get_akun($id){
        $SQL = "select *
                from tim_ceo
                where Tim_id = '".$id."' ";
        $data = $this->db->query($SQL)->result();
        return $data;
    }

    public function resetPassword($id){
        $new_password = $this->input->post('new_pwd');
        $old_password = $this->input->post('old_pwd');
        $data = array(
            'PASSWORD' => $new_password
        );
        $this->db->where('Tim_id', $id);
        $this->db->where('PASSWORD', $old_password);
        $this->db->update('tim_ceo', $data);

        if ($this->db->affected_rows()>0){
            return true;
        }
        else{
            return false;
        }
    }

    public function dashboardCBT($id){
        $sql_TO ="select Tim_id, dikerjakan
                   from tryout
                   where Tim_id = '".$id."' and dikerjakan = 'no' ";
        $sql_PE ="select Tim_id, dikerjakan
                   from penyisihan
                   where Tim_id = '".$id."' and dikerjakan = 'no' ";
        $sql_SE ="select Tim_id, dikerjakan
                  from semifinal
                  where Tim_id = '".$id."' and dikerjakan = 'no' ";
        
        $tryout = $this->db->query($sql_TO);
        if ($tryout->num_rows() > 0){
            $data['tryout']=true;
            }else{
            $data['tryout']=false;
            }
        
        $semifinal = $this->db->query($sql_SE);
        if ($semifinal->num_rows() > 0){
            $data['semifinal']=true;
            }else{
            $data['semifinal']=false;
            }

        $penyisihan = $this->db->query($sql_PE);
        if ($penyisihan->num_rows() > 0){
            $data['penyisihan']=true;
            }else{
            $data['penyisihan']=false;
            }
        
        return $data;
    }
}